revolve2.core.physics.actor package
===================================

Subpackages
-----------

.. toctree::
   :maxdepth: 1

   sdf <revolve2.core.physics.actor.sdf>
   urdf <revolve2.core.physics.actor.urdf>

Module contents
---------------

.. automodule:: revolve2.core.physics.actor
   :members:
   :undoc-members:
   :show-inheritance:
