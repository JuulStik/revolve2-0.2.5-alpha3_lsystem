from dataclasses import dataclass


@dataclass
class Item:
    weight: float
    value: float
