# from genotype import GenotypeSerializer, develop
# from sqlalchemy.ext.asyncio.session import AsyncSession
# from sqlalchemy.future import select
#
# from revolve2.core.database import open_async_database_sqlite
# from revolve2.core.database.serializers import DbFloat
# from revolve2.core.optimization.ea.generic_ea import DbEAOptimizerIndividual
# from revolve2.runners.isaacgym import ModularRobotRerunner
#
#
# async def main() -> None:
#
#     db = open_async_database_sqlite("/home/ibilgin/Desktop/lsystem_juul/revolve2-0.2.5-alpha3/ldatabase")
#     async with AsyncSession(db) as session:
#         best_individual = (
#             await session.execute(
#                 select(DbEAOptimizerIndividual, DbFloat)
#                 .filter(DbEAOptimizerIndividual.fitness_id == DbFloat.id)
#                 .order_by(DbFloat.value.desc())
#             )
#         ).first()
#
#         assert best_individual is not None
#
#         print(f"fitness: {best_individual[1].value}")
#
#         genotype = (
#             await GenotypeSerializer.from_database(
#                 session, [best_individual[0].genotype_id]
#             )
#         )[0]
#
#     rerunner = ModularRobotRerunner()
#     developed, morphology = develop(genotype)
#     # await rerunner.rerun(develop(genotype), 5)
#     await rerunner.rerun(developed, 5)
#
#
#
# if __name__ == "__main__":
#     import asyncio
#
#     asyncio.run(main())
#
#
from genotype import GenotypeSerializer, develop
from sqlalchemy.ext.asyncio.session import AsyncSession
from sqlalchemy.future import select

from revolve2.core.database import open_async_database_sqlite
from revolve2.core.database.serializers import DbFloat
from revolve2.core.optimization.ea.generic_ea import DbEAOptimizerIndividual
from revolve2.runners.isaacgym import ModularRobotRerunner


async def main() -> None:
    top_n = 2
    print(top_n)
    db = open_async_database_sqlite("/home/ibilgin/Desktop/lsystem_juul/revolve2-0.2.5-alpha3/ldatabaseFlat1")
    # db = open_async_database_sqlite("./databaseCppnFlat5x")

    async with AsyncSession(db) as session:
        top_n_individuals = (
            await session.execute(
                select(DbEAOptimizerIndividual, DbFloat)
                .filter((DbEAOptimizerIndividual.fitness_id == DbFloat.id)
                        & (DbFloat.value < 2.5))
                .order_by(DbFloat.value.desc()).limit(top_n)
            )
        )

        assert top_n_individuals is not None

        genotypes = []
        for individual in top_n_individuals:
            print(f"fitness: {individual[1].value}")
            genotype = (
                await GenotypeSerializer.from_database(
                    session, [individual[0].genotype_id]
                )
            )[0]
            # print(genotype)
            developed, _ = develop(genotype)
            genotypes.append(developed)


        # genotype = (
        #     await GenotypeSerializer.from_database(
        #         session, [best_individual[0].genotype_id]
        #     )
        # )[0]
    #
    rerunner = ModularRobotRerunner()
    await rerunner.rerun(genotypes, 5)


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())

