import random

from ..lsystem_genotype import Alphabet, LsystemConfig, lsystem
from .._genotype import Genotype


def generate_child_genotype(parent_genotypes, genotype_conf, crossover_conf):
    """
    Generates a child (individual) by randomly mixing production rules from two parents

    :param parents: parents to be used for crossover

    :return: child genotype
    """
    # print('generate child', parent_genotypes)
    grammar = {}
    crossover_attempt = random.uniform(0.0, 1.0)
    if crossover_attempt > crossover_conf.crossover_prob:
        grammar = parent_genotypes[0].genotype.grammar
    else:
        for letter in Alphabet.modules():
            parent = random.randint(0, 1)
            # gets the production rule for the respective letter
            grammar[letter[0]] = parent_genotypes[parent].genotype.grammar[letter[0]]

    genotype = lsystem(genotype_conf, "tmp")
    genotype.grammar = grammar
    return Genotype(genotype.clone())


def standard_crossover(parent_individuals, genotype_conf, crossover_conf):
    """
    Creates a child (individual) through crossover with two parents

    :param parent_genotypes: genotypes of the parents to be used for crossover
    :return: genotype result of the crossover
    """
    parent_genotypes = [p for p in parent_individuals]
    # print('crossover', parent_genotypes)
    new_genotype = generate_child_genotype(
        parent_genotypes, genotype_conf, crossover_conf
    )
    return new_genotype
