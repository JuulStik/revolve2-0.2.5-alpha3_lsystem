from __future__ import annotations

import sys
from random import Random

from revolve2.serialization import StaticData, Serializable, SerializeError
# from revolve2.core.optimization.ea.modular_robot import BodybrainGenotype

from .lsystem_genotype import lsystem, LsystemConfig
from .initialization import random_initialization
from .mutation.standard_mutation import standard_mutation
from .crossover.standard_crossover import standard_crossover
from .crossover.crossover import CrossoverConfig
from .mutation.mutation import MutationConfig
from .crossover import crossover
from ._genotype import Genotype as LsystemGenotype

# def main():
#     gen: lsystem = Genotype.random()
#     gen.mutate()

class Genotype(lsystem, Serializable):
    @classmethod
    def random(cls, num_initial_mutations=0) -> Genotype:
        genotype = LsystemGenotype(random_initialization(LsystemConfig()))
        for _ in range(num_initial_mutations):
            Genotype.mutate(genotype)

        return genotype

    @classmethod
    def mutate(self, Genotype) -> Genotype:
        genconf = LsystemConfig()
        mutconf = MutationConfig(mutation_prob=0.8, genotype_conf=genconf)
        return standard_mutation(Genotype, mutconf)

    @classmethod
    def crossover(self, parents):
        conf = CrossoverConfig(0.8)
        genconf = LsystemConfig()
        return standard_crossover(parents, crossover_conf=conf, genotype_conf=genconf)
        #return parents[0]

    def serialize(self) -> StaticData:
        test = {
            "body": self._body_genotype.serialize()
        }
        return test

    @classmethod
    def deserialize(cls, data: StaticData) -> Genotype:
        #if type(data) != dict:
        #    raise SerializeError()
        return lsystem.deserialize(data)
