class Uninitialized:
    pass
